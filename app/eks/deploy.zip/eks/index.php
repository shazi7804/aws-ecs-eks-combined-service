<?php echo "Running Container in EKS: ", gethostname(); ?>
