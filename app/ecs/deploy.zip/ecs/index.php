<?php echo "Running Container in ECS: ", gethostname(); ?>
